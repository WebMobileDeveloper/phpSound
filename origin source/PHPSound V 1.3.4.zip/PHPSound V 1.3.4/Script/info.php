<?php
// Software Name
$name = 'phpSound';

// Software Author
$author = 'phpSound';

// Software URL
$url = 'http://phpsound.com';

// Software Version
$version = '1.3.4';
?>